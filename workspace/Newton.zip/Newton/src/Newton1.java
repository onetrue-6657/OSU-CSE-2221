import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public final class Newton1 {

    private Newton1() {
    }

    private static double sqrt(double x) {
        double r = x;
        while (Math.abs(r * r - x) / x >= 0.0001 * 0.0001) {
            r = (r + x / r) / 2;
        }
        return r;
    }

    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        boolean judge = true;
        String inp;

        while (judge) {
            out.print("Please input a number to calculate the square root of it: ");
            double num = in.nextDouble();
            out.println("The square root of " + num + " using Newton Iteration is: "
                    + sqrt(num));
            out.print("Do you want to continue? ");
            inp = in.nextLine();
            if (!inp.equals("y")) {
                judge = false;
            }
        }

        in.close();
        out.close();
    }

}
